# Task 3 model answer
This Repo contains an example answer for task 3 of the PepsiCo Software Development Program by Forage