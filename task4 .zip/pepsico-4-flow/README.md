# Task 4 model answer
This Repo contains an example answer for task 4 of the PepsiCo Software Development Program by Forage

### The CD pipeline config can be found in the Github Actions tab of the repo
